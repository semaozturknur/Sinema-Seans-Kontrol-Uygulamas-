public class Film
{
    public int FilmId { get; set; }
    public string Ad { get; set; }
    public List<Seans> Seanslar { get; set; }
}
